--------------------------------------
This is a small program that is made to help you learn police codes for games like ERLC or others. The UI is made using pygame and my own "Library" PyGameUI. With the use of pyGameUI i could finish this program in about 5-7 hours when it normally would take much longer. For more information please visit TBF3D.com
-------------------------------------